# Bounded native startup diagnostic — prepared, not executed

As of preparation, the root's official same-host 30-trial W0 is still running.
Do not execute this plan until root confirms that workload has finished. This
diagnostic is not a substitute for the frozen end-to-end comparison or a reason
to keep an optimization by itself.

## Exact source and caller hypothesis

Baseline production: `47c6f6dd18fe822a6d28ea6970c756d5dfae7b95`.
Candidate production: `f9ce87b9f5cf37710f0a52ebe503595e5d7fdd7f`.
Only `astrolabe/losses/interaction.py` and `astrolabe/runtime_requirements.py`
change. The first combines the old opt native loader with the already verified
SciPy lazy imports; the second is byte-for-byte the old opt implementation.

Caller 1: `Astrolabe.run` → `_load_run_module` → `run.py` → loss registry discovery
→ `interaction`'s current eager PyRosetta import. Sequence-only W0 does not use a
native loss; the candidate defers this existing import to `_require_pyrosetta`.

Caller 2: `parse_arguments` → `build_persisted_run_config` → `_prune_env_sections`
→ `task_requirements` → `_pyrosetta_loss_types_from_source`. The existing scanner
calls `ast.get_source_segment` for each registered function. The recovered old
implementation splits each source into UTF-8 lines once, then slices AST byte
offsets. It keeps the same parsed tree, registration criteria, dependency
heuristics, returned set, and lru_cache. This caller runs in configuration
persistence as well as doctor; it can therefore affect a real cold repeat.

First-use native RNG and numerical semantics remain a separate C-owned native
gate. The local 22 tests and registry/missing-dependency guards do not certify
installed PyRosetta. No code changes to initialization, seeds, scientific
configuration, scheduling, broker/guardian, or repeat execution are proposed.

## Four cold processes, CPU only

Use the already inspected SIF:
`/xcf26/zpzeng/.gh_container/images/GuidedHallucination_af3_licensed_a13_20260722.sif`
and its `/alphafold3_venv/bin/python`. No image build, weights, GPU allocation,
`--nv`, native initialization, forward, sampling, or scientific evaluation.

Run **before, candidate, candidate, before**, one fresh Python process each.
`profile_cold_startup.py` pins the two owner file hashes before import. Each process
has a 19 s soft / 20 s hard CPU limit; at most four processes consume at most
80 Python CPU seconds. Reserve at most 10 additional CPU seconds for wrappers
and metadata, giving the requested 90 CPU-second diagnostic ceiling. Bound each
container invocation to 35 wall seconds with a 2 s termination grace, and stop
the plan after any timeout, source mismatch, or import failure. Failures count
against the four attempts. Do not silently retry, add warmups, or increase limits.

Each invocation saves stdout JSON phases and the unmodified `-X importtime` stderr.
The process file-size limit is 4 MB per output file; output can therefore be at
most 32 MB across four pairs of logs. Root must create fresh output and temporary
directories under its new cloud-20261104 delivery, not under an older worktree.

After root makes the reviewed source and adjacent probe available in its new
delivery, the exact argv form for each selected `REPO` / `VARIANT` is:

```text
timeout --signal=TERM --kill-after=2 35
  apptainer exec --cleanenv --contain
  --bind DELIVERY_ROOT:DELIVERY_ROOT
  --pwd REPO
  --env PYTHONPATH=REPO
  --env PYTHONNOUSERSITE=1
  --env PYTHONDONTWRITEBYTECODE=1
  --env CUDA_VISIBLE_DEVICES=
  --env NVIDIA_VISIBLE_DEVICES=
  --env GH_CUDA_PREINITIALIZE=0
  --env JAX_PLATFORMS=cpu
  --env OMP_NUM_THREADS=1
  --env MKL_NUM_THREADS=1
  --env OPENBLAS_NUM_THREADS=1
  --env NUMEXPR_NUM_THREADS=1
  /xcf26/zpzeng/.gh_container/images/GuidedHallucination_af3_licensed_a13_20260722.sif
  /alphafold3_venv/bin/python -X importtime
  PROFILE_SCRIPT --repo REPO --variant VARIANT
```

Construct this as an argv list; the multiline display is not shell syntax.
`DELIVERY_ROOT`, `REPO`, and `PROFILE_SCRIPT` are exact paths in the new root-owned
delivery. Configure host APPTAINER_TMPDIR and container TMPDIR to that delivery's
new private temporary directory; preserve all partial output. Wrapper startup
and rusage must be recorded, and no other profiling may overlap official W0.

Compare the two paired cold imports and first-source-scan phases; inspect native
importtime entries before calling either a dominant cost. An improvement here
is a causal diagnostic only. A KEEP requires independently reviewed native
semantics and the full unchanged scientific workload, successful work counts,
release gates, and same-host interleaved A/B improvement outside noise, with the
already validated 9d and d66 evidence kept visible. Otherwise revert the
performance candidate and retain all negative results.
