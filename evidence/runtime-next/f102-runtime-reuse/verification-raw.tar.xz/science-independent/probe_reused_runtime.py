#!/usr/bin/env python3
"""Independent CPU State/ledger ownership probes; controlled worker, no IPC/GPU."""
import argparse
import contextlib
import json
import os
import sys
import threading
import time
from pathlib import Path


def main(repo):
    sys.path.insert(0, str(repo.resolve()))
    for name in ("ASTROLABE_EXECUTION_ENDPOINT", "ASTROLABE_EXECUTION_TOKEN", "ASTROLABE_RUNTIME_TRACE", "ASTROLABE_EXECUTION_ARTIFACT_ROOT"):
        os.environ.pop(name, None)
    from astrolabe.runtime.broker_state import State
    from astrolabe.runtime.client import AdmissionRejected, OutcomeUnknown
    from astrolabe.runtime.contracts import ResourceLimits

    class Boundary:
        def __init__(self):
            self.hello = {"worker_epoch": "c-independent", "capabilities": {
                "request_staging": True, "cpu_phases": ["cpu_prepare", "cpu_finalize"],
                "phase_methods": {"prepare": "cpu_prepare", "finalize": "cpu_finalize"}}}
            self.lifecycle, self.last_metrics, self.calls = {}, {}, []
            self.error = None

        def call(self, payload, **kwargs):
            self.calls.append({"payload": payload.copy(), "request_id": kwargs["request_id"]})
            if self.error:
                raise self.error
            return {"observed": payload.copy()}

        def close(self):
            self.lifecycle["release_confirmed"] = True

    @contextlib.contextmanager
    def state():
        s = State("c-independent", 2, 2, limits=ResourceLimits(
            cpu_slots=1, ram_bytes=4096, prepared_bytes=4096, output_bytes=1024, pending_items=4))
        for name in ("one", "two"):
            s.workers[name] = {"client": Boundary(), "device": "cpu", "clients": {"owner": None, "other": None},
                "busy": 0, "shapes": set(), "cohort": name, "call_lock": threading.Lock(),
                "retained": {}, "delegated": None, "last_used": time.monotonic()}
        # No real process exists: substitute only the post-response resident
        # observations; State, ledger, cancellation and ownership remain real.
        s.ledger.update_resident = lambda *a, **kw: None
        s.ledger.observe_resident = lambda *a, **kw: None
        try:
            yield s
        finally:
            for token in tuple(s.ledger.pending):
                s.ledger.release(token)
            s.close()

    def request(rid, *, worker="one", method=None):
        p = {"handle": worker, "epoch": "owner", "request_id": rid, "timeout": 2.0,
             "payload": {"value": rid}, "runtime": {"resources": {"ram_bytes": 0, "output_bytes": 0}}}
        if method:
            p["payload"]["method"] = method
            p["runtime"].update(scientific_request_id="fixed-parent-science",
                phase="cpu_finalize" if method == "finalize" else "composite")
        return p

    def cancel(s, rid, epoch="owner"):
        return s.cancel({"handle": "one", "epoch": epoch, "target_request_id": rid})

    def asynchronous(s, req):
        result = {}
        def call():
            try:
                result["value"] = s.call(req)
            except BaseException as exc:
                result["error"] = type(exc).__name__
        t = threading.Thread(target=call)
        t.start()
        return t, result

    results = {}
    with state() as s:
        bad = s.workers["one"]["client"]
        bad.error = OutcomeUnknown("controlled transport loss after submission")
        errors = []
        for _ in range(2):
            try:
                s.call(request("uncertain"))
            except BaseException as exc:
                errors.append(type(exc).__name__)
        good = s.call(request("healthy", worker="two"))["result"]
        results["unknown_no_replay_and_cpu_scope"] = {
            "errors": errors, "bad_dispatch_count": len(bad.calls), "other_result": good,
            "worker_fenced": s.workers["one"].get("fenced"), "poisoned_devices": sorted(s.poisoned),
            "pass": errors == ["OutcomeUnknown", "ValueError"] and len(bad.calls) == 1
                and good == {"observed": {"value": "healthy"}} and not s.poisoned}

    with state() as s:
        worker = s.workers["one"]
        worker["call_lock"].acquire()
        t, result = asynchronous(s, request("queued"))
        try:
            limit = time.monotonic() + 1
            while ("owner", "queued") not in s.requests and time.monotonic() < limit:
                time.sleep(.001)
            assert ("owner", "queued") in s.requests
            wrong = cancel(s, "queued", "other")
            ack = cancel(s, "queued")
            t.join(1)
            assert not t.is_alive()
            before = len(worker["client"].calls)
        finally:
            worker["call_lock"].release()
            t.join(3)
        explicit = s.call(request("queued"))["result"]
        results["queued_cancel_not_executed_id_reusable"] = {
            "wrong_owner_ack": wrong, "ack": ack, "first_result": result,
            "dispatches_before_explicit_retry": before, "dispatches_after_explicit_retry": len(worker["client"].calls),
            "explicit_result": explicit, "waiting": s.metrics["waiting"],
            "pass": wrong["cancelled"] is False and ack == {"cancelled": True, "state": "queued", "release_confirmed": False}
                and result == {"error": "AdmissionRejected"} and before == 0
                and len(worker["client"].calls) == 1 and s.metrics["waiting"] == 0}

    with state() as s:
        worker = s.workers["one"]
        resources = {"prepared_bytes": 32, "ram_bytes": 0, "output_bytes": 0}
        retained = {"token": "prepared", "resources": resources, "state": "prepared"}
        worker["retained"][("owner", "fixed-parent-science")] = retained
        s.ledger.admit_pending("prepared", resources)
        s.ledger.admit_pending("blocker", {"ram_bytes": 0, "output_bytes": 0})
        s.ledger.acquire_compute("blocker", "cpu")
        entered = threading.Event()
        original = s.ledger._wait
        def waiting(predicate, deadline, reason, cancel_token=None):
            if not predicate() and cancel_token:
                entered.set()
            return original(predicate, deadline, reason, cancel_token)
        s.ledger._wait = waiting
        t, result = asynchronous(s, request("execute", method="execute"))
        try:
            assert entered.wait(1)
            ack = cancel(s, "execute")
            t.join(1)
            assert not t.is_alive()
            preserved = (worker["retained"].get(("owner", "fixed-parent-science")) is retained
                and "prepared" in s.ledger.pending and "prepared" not in s.ledger.active)
            before = len(worker["client"].calls)
        finally:
            s.ledger.release("blocker")
            t.join(3)
        s.call(request("execute", method="execute"))
        executed = worker["retained"][("owner", "fixed-parent-science")]["state"]
        s.call(request("finalize", method="finalize"))
        results["prepared_cancel_preserves_science_until_explicit_resume"] = {
            "ack": ack, "first_result": result, "same_prepared_owner": preserved,
            "dispatches_before_explicit_resume": before, "state_after_execute": executed,
            "dispatches_after_finalize": len(worker["client"].calls), "retained_after_finalize": len(worker["retained"]),
            "pending_after_finalize": len(s.ledger.pending), "waiting": s.metrics["waiting"],
            "pass": result == {"error": "AdmissionRejected"} and preserved and before == 0
                and executed == "executed" and len(worker["client"].calls) == 2
                and not worker["retained"] and not s.ledger.pending and s.metrics["waiting"] == 0}
    return {"status": "PASS" if all(x["pass"] for x in results.values()) else "FAIL",
            "scope": "Real State/ledger/cancellation with controlled worker boundary and explicitly substituted process observations; no IPC, pretrained model, GPU or throughput evidence", "cases": results}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = main(args.repo)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(result["status"] != "PASS")
