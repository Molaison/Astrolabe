# Runtime CPU W0 comparison

Status: **DONE**. Completed trial contract: **True**.
Baseline: `9d62b3eb86cb75a2266af49dc48cb851e69e0341`. Candidate: `f9ce87b9f5cf37710f0a52ebe503595e5d7fdd7f`.
Protocol: `f2636de19cdb90c2707a24969da016c398ba13b71c70fc4cde7e2fa00e7855e5`. 30 / 30 trials attempted.

| Revision / mode | Valid / attempted | Evaluations | Median seconds | Range seconds | Effective trajectories/s |
| --- | ---: | ---: | ---: | --- | ---: |
| baseline/direct | 5 / 5 | 45 | 10.8418 | 9.2925 – 14.6258 | 0.2623 |
| baseline/resident_serial | 5 / 5 | 45 | 34.3922 | 33.0141 – 38.8537 | 0.0844 |
| baseline/resident_adaptive | 5 / 5 | 45 | 33.6292 | 31.6925 – 36.3168 | 0.0878 |
| candidate/direct | 5 / 5 | 45 | 6.2164 | 5.9465 – 8.0968 | 0.4435 |
| candidate/resident_serial | 5 / 5 | 45 | 19.9586 | 19.5803 – 23.7200 | 0.1434 |
| candidate/resident_adaptive | 5 / 5 | 45 | 20.0297 | 19.3712 – 25.8335 | 0.1360 |

Scientific gate across both revisions and every mode: **True**.
Baseline direct repeats alone define numerical tolerance. Candidate direct cannot widen it.

| Same mode | Median baseline / candidate seconds | Faster pairs / 5 | All five improved | Nonoverlapping time ranges |
| --- | ---: | ---: | --- | --- |
| direct | 1.6021 | 5 | True | True |
| resident_serial | 1.6541 | 5 | True | True |
| resident_adaptive | 1.6361 | 5 | True | True |

Ratios above one favor the candidate. Incomplete work or failed scientific/release checks suppress every speed ratio and effective-throughput number.

| Candidate mode | Best direct revision | Median direct / candidate seconds |
| --- | --- | ---: |
| direct | candidate | 1.0000 |
| resident_serial | candidate | 0.3106 |
| resident_adaptive | candidate | 0.3092 |

CPU W0 timings only; inspect paired variation

BLOCKED: CPU Dummy workload, no model weights or GPU execution

All trials start fresh; no warmup, extra trajectories or profiler is added. The existing 30 ms observer times process-tree completion and verifies release. Raw stdout/stderr, configs, traces, telemetry, source manifests, scientific rows and failed trials are retained.
