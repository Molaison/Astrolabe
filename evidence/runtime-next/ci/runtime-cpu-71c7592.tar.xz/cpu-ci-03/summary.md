# Astrolabe runtime validation

Overall CPU validation: **DONE**.
Candidate: `71c7592e27d02b2772d984d9b1f5ed9fea47fd6c`. Frozen baseline: `d66ee714f2e755948534f95d9d125287ce8dbd91`.

| Gate | Status |
| --- | --- |
| preflight | DONE |
| regressions | DONE |
| comparison | DONE |

# Runtime CPU W0 comparison

Status: **DONE**. Completed trial contract: **True**.
Protocol: `f2636de19cdb90c2707a24969da016c398ba13b71c70fc4cde7e2fa00e7855e5`. 30 / 30 trials attempted.

| Revision / mode | Valid / attempted | Evaluations | Median seconds | Range seconds | Effective trajectories/s |
| --- | ---: | ---: | ---: | --- | ---: |
| baseline/direct | 5 / 5 | 45 | 2.0261 | 2.0186 – 2.2950 | 1.4388 |
| baseline/resident_serial | 5 / 5 | 45 | 5.4685 | 5.3690 – 5.5285 | 0.5504 |
| baseline/resident_adaptive | 5 / 5 | 45 | 5.4677 | 5.3627 – 5.5632 | 0.5490 |
| candidate/direct | 5 / 5 | 45 | 1.8798 | 1.8484 – 1.9530 | 1.5928 |
| candidate/resident_serial | 5 / 5 | 45 | 4.7865 | 4.7416 – 4.8503 | 0.6263 |
| candidate/resident_adaptive | 5 / 5 | 45 | 4.7920 | 4.7309 – 4.9220 | 0.6242 |

Scientific gate across both revisions and every mode: **True**.
Baseline direct repeats alone define numerical tolerance. Candidate direct cannot widen it.

| Same mode | Median baseline / candidate seconds | Faster pairs / 5 | All five improved | Nonoverlapping time ranges |
| --- | ---: | ---: | --- | --- |
| direct | 1.0927 | 5 | True | True |
| resident_serial | 1.1398 | 5 | True | True |
| resident_adaptive | 1.1256 | 5 | True | True |

Ratios above one favor the candidate. Incomplete work or failed scientific/release checks suppress every speed ratio and effective-throughput number.

| Candidate mode | Best direct revision | Median direct / candidate seconds |
| --- | --- | ---: |
| direct | candidate | 1.0000 |
| resident_serial | candidate | 0.3941 |
| resident_adaptive | candidate | 0.3923 |

CPU W0 timings only; inspect paired variation

BLOCKED: CPU Dummy workload, no model weights or GPU execution

All trials start fresh; no warmup, extra trajectories or profiler is added. The existing 30 ms observer times process-tree completion and verifies release. Raw stdout/stderr, configs, traces, telemetry, source manifests, scientific rows and failed trials are retained.


Real pretrained GPU backend certification: **BLOCKED** in this CPU-only job.
The uploaded artifact preserves raw logs, configuration, traces, telemetry, test cases and skip reasons. Missing runs and failed work are retained and cannot count as acceleration.
