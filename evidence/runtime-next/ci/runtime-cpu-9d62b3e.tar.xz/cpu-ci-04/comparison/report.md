# Runtime CPU W0 comparison

Status: **DONE**. Completed trial contract: **True**.
Protocol: `f2636de19cdb90c2707a24969da016c398ba13b71c70fc4cde7e2fa00e7855e5`. 30 / 30 trials attempted.

| Revision / mode | Valid / attempted | Evaluations | Median seconds | Range seconds | Effective trajectories/s |
| --- | ---: | ---: | ---: | --- | ---: |
| baseline/direct | 5 / 5 | 45 | 2.9347 | 2.8565 – 3.2777 | 1.0041 |
| baseline/resident_serial | 5 / 5 | 45 | 7.5480 | 7.4678 – 7.6758 | 0.3966 |
| baseline/resident_adaptive | 5 / 5 | 45 | 7.6069 | 7.4841 – 7.7559 | 0.3939 |
| candidate/direct | 5 / 5 | 45 | 2.6723 | 2.6415 – 2.7453 | 1.1201 |
| candidate/resident_serial | 5 / 5 | 45 | 6.7115 | 6.5728 – 6.7799 | 0.4492 |
| candidate/resident_adaptive | 5 / 5 | 45 | 6.6627 | 6.6133 – 6.8662 | 0.4467 |

Scientific gate across both revisions and every mode: **True**.
Baseline direct repeats alone define numerical tolerance. Candidate direct cannot widen it.

| Same mode | Median baseline / candidate seconds | Faster pairs / 5 | All five improved | Nonoverlapping time ranges |
| --- | ---: | ---: | --- | --- |
| direct | 1.0948 | 5 | True | True |
| resident_serial | 1.1362 | 5 | True | True |
| resident_adaptive | 1.1317 | 5 | True | True |

Ratios above one favor the candidate. Incomplete work or failed scientific/release checks suppress every speed ratio and effective-throughput number.

| Candidate mode | Best direct revision | Median direct / candidate seconds |
| --- | --- | ---: |
| direct | candidate | 1.0000 |
| resident_serial | candidate | 0.4019 |
| resident_adaptive | candidate | 0.3998 |

CPU W0 timings only; inspect paired variation

BLOCKED: CPU Dummy workload, no model weights or GPU execution

All trials start fresh; no warmup, extra trajectories or profiler is added. The existing 30 ms observer times process-tree completion and verifies release. Raw stdout/stderr, configs, traces, telemetry, source manifests, scientific rows and failed trials are retained.
