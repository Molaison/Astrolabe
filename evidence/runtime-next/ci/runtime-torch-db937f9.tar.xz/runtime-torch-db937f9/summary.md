# Astrolabe CPU Torch contract validation

Overall CPU validation: **DONE**.
Candidate: `db937f9706270cb109e799cda29f52d2872726b5`.

| Gate | Status |
| --- | --- |
| preflight | DONE |
| regressions | DONE |

Scope: CPU Torch worker, output-boundary and lifecycle tests, including local fake-weight fixtures. No pretrained inference or performance benchmark is certified by this job.

Real pretrained GPU backend certification: **BLOCKED** in this CPU-only job.
The uploaded artifact preserves raw logs, configuration, traces, telemetry, test cases and skip reasons. Missing runs and failed work are retained and cannot count as acceleration.
