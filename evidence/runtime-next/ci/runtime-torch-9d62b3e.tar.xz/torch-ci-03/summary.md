# Astrolabe CPU Torch and structural contract validation

Overall CPU validation: **DONE**.
Candidate: `9d62b3eb86cb75a2266af49dc48cb851e69e0341`.

| Gate | Status |
| --- | --- |
| preflight | DONE |
| regressions | DONE |

Scope: CPU Torch worker, output-boundary and lifecycle tests (including local fake-weight fixtures), plus structural loss tests using real SciPy/RDKit. No pretrained inference or performance benchmark is certified by this job.

Real pretrained GPU backend certification: **BLOCKED** in this CPU-only job.
The uploaded artifact preserves raw logs, configuration, traces, telemetry, test cases and skip reasons. Missing runs and failed work are retained and cannot count as acceleration.
