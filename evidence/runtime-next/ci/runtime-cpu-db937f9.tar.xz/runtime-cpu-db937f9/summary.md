# Astrolabe runtime validation

Overall CPU validation: **DONE**.
Candidate: `db937f9706270cb109e799cda29f52d2872726b5`. Frozen baseline: `d66ee714f2e755948534f95d9d125287ce8dbd91`.

| Gate | Status |
| --- | --- |
| preflight | DONE |
| regressions | DONE |
| comparison | DONE |

# Runtime CPU W0 comparison

Status: **DONE**. Completed trial contract: **True**.
Protocol: `f2636de19cdb90c2707a24969da016c398ba13b71c70fc4cde7e2fa00e7855e5`. 30 / 30 trials attempted.

| Revision / mode | Valid / attempted | Evaluations | Median seconds | Range seconds | Effective trajectories/s |
| --- | ---: | ---: | ---: | --- | ---: |
| baseline/direct | 5 / 5 | 45 | 1.5899 | 1.5127 – 1.9216 | 1.7962 |
| baseline/resident_serial | 5 / 5 | 45 | 4.2480 | 4.0408 – 4.9472 | 0.6807 |
| baseline/resident_adaptive | 5 / 5 | 45 | 4.3235 | 3.9904 – 4.8082 | 0.6886 |
| candidate/direct | 5 / 5 | 45 | 1.6331 | 1.4985 – 1.7099 | 1.8616 |
| candidate/resident_serial | 5 / 5 | 45 | 4.1897 | 4.0630 – 4.7036 | 0.6904 |
| candidate/resident_adaptive | 5 / 5 | 45 | 4.2931 | 4.1374 – 4.7677 | 0.6825 |

Scientific gate across both revisions and every mode: **True**.
Baseline direct repeats alone define numerical tolerance. Candidate direct cannot widen it.

| Same mode | Median baseline / candidate seconds | Faster pairs / 5 | All five improved | Nonoverlapping time ranges |
| --- | ---: | ---: | --- | --- |
| direct | 1.0254 | 3 | False | False |
| resident_serial | 1.0202 | 3 | False | False |
| resident_adaptive | 0.9802 | 2 | False | False |

Ratios above one favor the candidate. Incomplete work or failed scientific/release checks suppress every speed ratio and effective-throughput number.

| Candidate mode | Best direct revision | Median direct / candidate seconds |
| --- | --- | ---: |
| direct | baseline | 1.0254 |
| resident_serial | baseline | 0.3845 |
| resident_adaptive | baseline | 0.3714 |

CPU W0 timings only; inspect paired variation

BLOCKED: CPU Dummy workload, no model weights or GPU execution

All trials start fresh; no warmup, extra trajectories or profiler is added. The existing 30 ms observer times process-tree completion and verifies release. Raw stdout/stderr, configs, traces, telemetry, source manifests, scientific rows and failed trials are retained.


Real pretrained GPU backend certification: **BLOCKED** in this CPU-only job.
The uploaded artifact preserves raw logs, configuration, traces, telemetry, test cases and skip reasons. Missing runs and failed work are retained and cannot count as acceleration.
