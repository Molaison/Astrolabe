# Astrolabe runtime validation

Overall CPU validation: **DONE**.
Candidate: `6620da607e66d569eed802057d77b0fbfa9c37b4`; frozen baseline: `d66ee714f2e755948534f95d9d125287ce8dbd91`.

| Gate | Status |
| --- | --- |
| preflight | DONE |
| regressions | DONE |
| comparison | DONE |

# Runtime CPU W0 comparison

Status: **DONE**. Completed trial contract: **True**.
Protocol: `f2636de19cdb90c2707a24969da016c398ba13b71c70fc4cde7e2fa00e7855e5`. 30 / 30 trials attempted.

| Revision / mode | Valid / attempted | Evaluations | Median seconds | Range seconds | Effective trajectories/s |
| --- | ---: | ---: | ---: | --- | ---: |
| baseline/direct | 5 / 5 | 45 | 2.7900 | 2.7832 – 3.1767 | 1.0451 |
| baseline/resident_serial | 5 / 5 | 45 | 7.3248 | 7.2830 – 7.4687 | 0.4082 |
| baseline/resident_adaptive | 5 / 5 | 45 | 7.3731 | 7.3205 – 7.4543 | 0.4067 |
| candidate/direct | 5 / 5 | 45 | 2.8286 | 2.7956 – 2.9146 | 1.0563 |
| candidate/resident_serial | 5 / 5 | 45 | 7.2894 | 7.2401 – 7.3570 | 0.4114 |
| candidate/resident_adaptive | 5 / 5 | 45 | 7.3085 | 7.2781 – 7.4530 | 0.4093 |

Scientific gate across both revisions and every mode: **True**.
Baseline direct repeats alone define numerical tolerance. Candidate direct cannot widen it.

| Same mode | Median baseline / candidate seconds | Faster pairs / 5 | All five improved | Nonoverlapping time ranges |
| --- | ---: | ---: | --- | --- |
| direct | 0.9912 | 1 | False | False |
| resident_serial | 1.0070 | 3 | False | False |
| resident_adaptive | 1.0076 | 4 | False | False |

Ratios above one favor the candidate. Incomplete work or failed scientific/release checks suppress every speed ratio and effective-throughput number.

| Candidate mode | Best direct revision | Median direct / candidate seconds |
| --- | --- | ---: |
| direct | baseline | 0.9912 |
| resident_serial | baseline | 0.3836 |
| resident_adaptive | baseline | 0.3822 |

CPU W0 timings only; inspect paired variation

BLOCKED: CPU Dummy workload, no model weights or GPU execution

All trials start fresh; no warmup, extra trajectories or profiler is added. The existing 30 ms observer times process-tree completion and verifies release. Raw stdout/stderr, configs, traces, telemetry, source manifests, scientific rows and failed trials are retained.


Real pretrained GPU backend certification: **BLOCKED** in this CPU-only job.
The uploaded artifact preserves raw logs, configuration, traces, telemetry, test cases and skip reasons. Missing runs and failed work are retained and cannot count as acceleration.
