"""Offline original-artifact audit. No model construction or native/GPU run."""
import ast
import collections
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

evidence, source, accounting = (Path(value).resolve() for value in sys.argv[1:4])
raw = evidence / 'raw'
frozen_path = raw / 'gpu-control-01/frozen.json'
frozen = json.loads(frozen_path.read_text())
protocol = json.loads((source / 'benchmarks/runtime/workloads/proteinmpnn_gpu_control.json').read_text())
assert frozen['protocol'] == protocol
assert hashlib.sha256(frozen_path.read_bytes()).hexdigest() == '21460a82249fadffde75bc0ce058af40548e85daf7aa29851b2fea992e72310a'
for relative, expected in frozen['source_sha256'].items():
    assert hashlib.sha256((source / relative).read_bytes()).hexdigest() == expected
for name, expected in frozen['cpu_preflight']['parsed_input_sha256'].items():
    assert hashlib.sha256((raw / 'gpu-control-01/parsed_input' / name).read_bytes()).hexdigest() == expected
pdb = (raw / 'gpu-control-01/input.pdb').read_bytes()
assert len(pdb) == protocol['assets']['pdb']['bytes']
assert hashlib.sha256(pdb).hexdigest() == protocol['assets']['pdb']['sha256']

sys.path.insert(0, str(source))
import torch
from astrolabe.evaluators.tree_codec import load_tree
assert torch.version.cuda is None and not torch.cuda.is_initialized()
parsed = load_tree(raw / 'gpu-control-01/parsed_input')['protein']
assert list(parsed['X'].shape) == [354, 4, 3] and torch.isfinite(parsed['X']).all()
assert list(parsed['S'].shape) == [354]
assert list(parsed['mask'].shape) == [354] and bool((parsed['mask'] == 1).all())
assert list(parsed['chain_letters']) == ['A'] * 177 + ['B'] * 177
tree = ast.parse((source / 'astrolabe/mutators/wrappers/ligandmpnn_utils.py').read_text())
mapping = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
               and any(isinstance(target, ast.Name) and target.id == 'restype_int_to_str' for target in node.targets))
sequence = ''.join(mapping[int(index)] for index in parsed['S'])
assert sequence == frozen['cpu_preflight']['native_sequence']
assert hashlib.sha256(sequence.encode()).hexdigest() == protocol['assets']['pdb']['native_sequence_sha256']

def completed_record(name):
    record = json.loads((accounting / name).read_text())
    result = record['response']['result']
    assert record['response']['execution'] == 'accepted' and result['status'] == 'exited'
    assert result['exitCode'] == 0 and result['outputTruncated'] is False
    return result['stdout']

fields = ['job_id', 'job_name', 'user', 'uid', 'account', 'partition', 'qos', 'state', 'exit_code',
          'submit', 'eligible', 'start', 'end', 'elapsed_raw', 'allocated_cpus', 'nodes_requested',
          'requested_tres', 'allocated_tres', 'node_list']
rows = list(csv.reader(completed_record('sacct.json').splitlines(), delimiter='|'))
assert len(rows) == 1 and len(rows[0]) == len(fields)
job = dict(zip(fields, rows[0]))
assert job['job_id'] == '33334' and job['uid'] == '7054' and job['user'] == 'zpzeng'
assert [job[key] for key in ['account', 'partition', 'qos']] == ['xulab', 'boron', 'normal']
assert job['state'] == 'CANCELLED by 7054' and job['start'] == 'None'
assert job['elapsed_raw'] == job['allocated_cpus'] == '0'
assert job['allocated_tres'] == '' and job['node_list'] == 'None assigned'
assert not completed_record('squeue.json').strip()
spec = importlib.util.spec_from_file_location('frozen_launcher', source / 'benchmarks/runtime/gpu_slurm_launcher.py')
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)
job_control = launcher.parse_scontrol(completed_record('scontrol.json'))
assert job_control['JobId'] == job['job_id'] and job_control['JobState'] == 'CANCELLED'
assert job_control['NodeList'] == '' and job_control['AllocTRES'] == '(null)'
submission = json.loads((raw / 'gpu-allocation-01/submission.json').read_text())
launch = json.loads((raw / 'gpu-allocation-01/launch.json').read_text())
assert job['job_name'] == launch['job_name'] == job_control['JobName']
assert '--job-name=' + job['job_name'] in submission['srun_argv']
assert submission['srun_exit_code'] == 1 and submission['status'] == 'PARTIAL_ACCOUNTING_OR_BUDGET'
assert submission['launch_sha256'] == hashlib.sha256((raw / 'gpu-allocation-01/launch.json').read_bytes()).hexdigest()
stderr = (raw / 'gpu-allocation-01/srun.stderr.txt').read_text()
assert 'job 33334 queued' in stderr and 'Requested nodes are busy' in stderr
assert not (raw / 'gpu-allocation-01/allocation.json').exists()
assert not (raw / 'gpu-control-01/execution.json').exists()
assert not (raw / 'gpu-control-01/trials').exists()

report = {
    'status': 'PASS_OFFLINE_EVIDENCE_CHECKS',
    'runner_outcome': 'BLOCKED_ADMISSION',
    'gpu_execution': 'NOT_RUN',
    'source_files_verified': len(frozen['source_sha256']),
    'cpu_artifact': {'pdb_bytes': len(pdb), 'pdb_sha256': hashlib.sha256(pdb).hexdigest(),
        'coordinate_shape': list(parsed['X'].shape), 'coordinate_dtype': str(parsed['X'].dtype),
        'finite_coordinates': True, 'residues': len(sequence), 'input_mask_sum': int(parsed['mask'].sum()),
        'chain_counts': dict(collections.Counter(parsed['chain_letters'])),
        'chain_order': 'A177 then B177', 'native_sequence_sha256': hashlib.sha256(sequence.encode()).hexdigest()},
    'accounting_from_independent_A_raw': job,
    'accounting_raw_sha256': {name: hashlib.sha256((accounting / name).read_bytes()).hexdigest()
                            for name in ['sacct.json', 'scontrol.json', 'squeue.json']},
    'allocated_gpu_count': 0, 'allocation_gpu_hours': 0.0,
    'future_scontrol_start_excluded': job_control['StartTime'],
    'srun_client_wall_seconds': submission['client_wall_seconds'],
    'original_launcher_status_preserved': submission['status'],
    'gpu_trials_started': 0, 'gpu_requests_completed': 0,
    'gpu_parity_rng_model_reuse_and_throughput': 'NOT_RUN',
    'gpu_throughput': None,
    'review_environment': {'torch': str(torch.__version__), 'cuda_build': torch.version.cuda,
                           'cuda_initialized': torch.cuda.is_initialized()},
    'scope': 'CPU reload of original parsed input and independent parse of A native accounting captures; no model construction, forward, sampling, scheduler command or GPU action by this script',
}
(evidence / 'cpu-and-admission-review.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, indent=2, sort_keys=True))
