# Astrolabe runtime validation

Overall CPU validation: **DONE**.
Candidate: `1bdaf3a53227c9197b930dc00a01b752acd90067`. Compared baseline: `d66ee714f2e755948534f95d9d125287ce8dbd91`.

| Gate | Status |
| --- | --- |
| preflight | DONE |
| regressions | DONE |
| comparison | DONE |

# Runtime CPU W0 comparison

Status: **DONE**. Completed trial contract: **True**.
Baseline: `d66ee714f2e755948534f95d9d125287ce8dbd91`. Candidate: `1bdaf3a53227c9197b930dc00a01b752acd90067`.
Protocol: `f2636de19cdb90c2707a24969da016c398ba13b71c70fc4cde7e2fa00e7855e5`. 30 / 30 trials attempted.

| Revision / mode | Valid / attempted | Evaluations | Median seconds | Range seconds | Effective trajectories/s |
| --- | ---: | ---: | ---: | --- | ---: |
| baseline/direct | 5 / 5 | 45 | 2.5164 | 2.4847 – 2.9207 | 1.1588 |
| baseline/resident_serial | 5 / 5 | 45 | 6.5937 | 6.5217 – 6.7618 | 0.4523 |
| baseline/resident_adaptive | 5 / 5 | 45 | 6.6293 | 6.5286 – 6.8108 | 0.4511 |
| candidate/direct | 5 / 5 | 45 | 1.5842 | 1.5490 – 1.6282 | 1.8982 |
| candidate/resident_serial | 5 / 5 | 45 | 3.6120 | 3.5157 – 3.6505 | 0.8337 |
| candidate/resident_adaptive | 5 / 5 | 45 | 3.5588 | 3.5187 – 3.6121 | 0.8421 |

Scientific gate across both revisions and every mode: **True**.
Baseline direct repeats alone define numerical tolerance. Candidate direct cannot widen it.

| Same mode | Median baseline / candidate seconds | Faster pairs / 5 | All five improved | Nonoverlapping time ranges |
| --- | ---: | ---: | --- | --- |
| direct | 1.6040 | 5 | True | True |
| resident_serial | 1.8190 | 5 | True | True |
| resident_adaptive | 1.8747 | 5 | True | True |

Ratios above one favor the candidate. Incomplete work or failed scientific/release checks suppress every speed ratio and effective-throughput number.

| Candidate mode | Best direct revision | Median direct / candidate seconds |
| --- | --- | ---: |
| direct | candidate | 1.0000 |
| resident_serial | candidate | 0.4351 |
| resident_adaptive | candidate | 0.4451 |

CPU W0 timings only; inspect paired variation

BLOCKED: CPU Dummy workload, no model weights or GPU execution

All trials start fresh; no warmup, extra trajectories or profiler is added. The existing 30 ms observer times process-tree completion and verifies release. Raw stdout/stderr, configs, traces, telemetry, source manifests, scientific rows and failed trials are retained.


Real pretrained GPU backend certification: **BLOCKED** in this CPU-only job.
The uploaded artifact preserves raw logs, configuration, traces, telemetry, test cases and skip reasons. Missing runs and failed work are retained and cannot count as acceleration.
