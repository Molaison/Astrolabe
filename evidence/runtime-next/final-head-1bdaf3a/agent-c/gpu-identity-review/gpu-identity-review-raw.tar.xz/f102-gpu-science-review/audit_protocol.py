#!/usr/bin/env python3
"""Offline scientific protocol audit, independent of the GPU benchmark harness."""
import argparse
import ast
import hashlib
import json
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def audit(repo, preflight):
    workload = repo / "benchmarks/runtime/workloads/proteinmpnn_gpu_control.json"
    raw = workload.read_bytes()
    p = json.loads(raw)
    observation = json.loads(preflight.read_text())["completed"]["result"]
    assert observation["status"] == "exited" and observation["exitCode"] == 0
    assert not observation["outputTruncated"]
    parsed = json.loads(observation["stdout"])
    checks = {}
    checks["input_identity"] = p["assets"]["pdb"]["sha256"] == "c05c06773ae8c00d2d033f7f7a103c4048981d79418c6c1a2579b15da455b2b7" and p["assets"]["pdb"]["bytes"] == 531114
    checks["checkpoint_identity"] = p["assets"]["checkpoint"]["sha256"] == "c9cb4a671d79604111231f8dbfc7c590e06f1197453b7a6854ac6661a642f5bd" and p["assets"]["checkpoint"]["bytes"] == 6681301
    checks["budget"] = p["groups"] == [17,18,19,20,21] and p["requests_per_trial"] == 3 and p["warmup_requests"] == 0
    checks["paired_order"] = p["mode_order"] == [["legacy","resident"],["resident","legacy"],["legacy","resident"],["resident","legacy"],["legacy","resident"]]
    ctor, decode = p["constructor"], p["decode"]
    checks["model_and_scientific_settings"] = ctor["model_type"] == "protein_mpnn" and ctor["temperature"] == 0.3 and ctor["omit_AA"] == ["C"] and ctor["parse_atoms_with_zero_occupancy"] == 1 and ctor["number_of_batches"] == 1
    checks["parse_chain_argument"] = decode["parse_these_chains_only"] == ["A","B"]
    checks["design_scope"] = decode["chains_to_design"] == "A,B" and decode["batch_size"] == 1 and decode["homo_oligomer"] == 0
    checks["decode_semantics"] = decode["distribution_semantics"] == "legacy_order_conditioned_marginals" and decode["reference_decoding_ranks"] is None and decode["return_joint_sequence"] is False
    empty_fields = ("fixed_residues", "fixed_residues_multi", "symmetry_residues", "symmetry_weights", "pdb_path_multi", "redesigned_residues_multi", "redesigned_residues", "bias_AA_per_residue_multi", "bias_AA_per_residue", "omit_AA_per_residue_multi", "omit_AA_per_residue", "transmembrane_buried", "transmembrane_interface", "transmembrane_buried_multi", "transmembrane_interface_multi")
    checks["no_hidden_scientific_constraints"] = all(decode[x] == "" for x in empty_fields) and ctor["bias_AA"] == "" and ctor["bias_mode"] == "additive" and ctor["design_pattern"] == "" and ctor["design_pattern_range"] == ""
    checks["numerical_settings_match_cpu_sif_observation"] = p["numerical_settings"] == parsed["settings"]
    checks["cpu_parse_full_input"] = parsed["chain_counts"] == {"A":177,"B":177} and parsed["shapes"]["X"] == [354,4,3] and parsed["shapes"]["S"] == [354] and parsed["shapes"]["mask"] == [354] and parsed["mask_sum"] == 354 and parsed["mask_values"] == [1] and parsed["cuda_initialized"] is False
    checks["native_sequence_evidence"] = sha(parsed["native_sequence"].encode()) == "a149f24cd9a0ca21eaeed7478450b91dfec6800b5d372e06655511e6b49a8e44" and len(parsed["native_sequence"]) == 354
    exact = set(p["scientific_gates"]["exact"])
    checks["discrete_and_rng_gates"] = {"S","decoding_order","chain_letters","alphabet","distribution_semantics","python_rng","numpy_rng","torch_cpu_rng","torch_cuda_rng","numerical_settings"} <= exact
    checks["float_gate"] = set(p["scientific_gates"]["float_keys"]) == {"sampling_probs","log_probs","logits"} and p["scientific_gates"]["rtol"] == 1e-5 and p["scientific_gates"]["atol"] == 1e-6
    source_hashes = {}
    for name, expected in p["native_sources"].items():
        actual = sha((repo / name).read_bytes())
        source_hashes[name] = actual
        checks["native_source:" + name] = actual == expected
    native = ast.parse((repo / "astrolabe/mutators/wrappers/ligandmpnn_run.py").read_text())
    cls = next(x for x in native.body if isinstance(x, ast.ClassDef) and x.name == "LigandMPNN")
    design = next(x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == "design_sequences")
    arguments = [x.arg for x in design.args.args][1:]
    checks["all_native_decode_parameters_explicit"] = set(arguments) == set(decode)
    errors = [k for k, ok in checks.items() if not ok]
    return {"status": "PASS" if not errors else "FAIL", "scope": "Offline protocol/source and independently parsed B CPU-native raw observation; no model forward or GPU run", "workload_path": str(workload), "workload_sha256": sha(raw), "native_source_sha256": source_hashes, "preflight_sha256": sha(preflight.read_bytes()), "checks": checks, "errors": errors, "observed_cpu_parse": parsed, "expected_model_loads": 10, "expected_decode_calls": 30}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--preflight", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.repo, args.preflight)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"], "workload_sha256": result["workload_sha256"], "errors": result["errors"]}))
    raise SystemExit(bool(result["errors"]))
