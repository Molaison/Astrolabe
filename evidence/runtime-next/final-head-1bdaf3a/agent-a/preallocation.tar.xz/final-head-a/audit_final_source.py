"""Read-only exact-source audit. Writes evidence only beside this script."""
import datetime
import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
REPO = OUT.parent.parent / 'integration-f102'
FINAL = '5db26b44cdf2d229ca35558f611b8b645ead881b'
REMOTE = '1bdaf3a53227c9197b930dc00a01b752acd90067'
TREE = '6f763bfb04778ef4f32386ddb8aeb38ce4240bf1'
TESTED = 'f9ce87b9f5cf37710f0a52ebe503595e5d7fdd7f'
BASE = 'd66ee714f2e755948534f95d9d125287ce8dbd91'
MEASUREMENT = (
    'scripts/validation/runtime_workflow_benchmark.py',
    'scripts/validation/runtime_benchmark_processes.py',
    'scripts/validation/runtime_trace_report.py',
    'scripts/validation/runtime_structure_parity.py',
)
PREFIXES = ('astrolabe/', 'config/', 'container/', 'patches/', 'vendor/',
            'resources/', 'data/', 'examples/')
FILES = ('run.py', 'setup.py', 'pyproject.toml', 'MANIFEST.in', 'justfile', '.gitmodules')

def git(*args):
    return subprocess.check_output(['git'] + list(args), cwd=str(REPO))

def text(*args):
    return git(*args).decode('utf-8')

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def tree(ref):
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if not row:
            continue
        meta, path = row.split(b'\t', 1)
        mode, kind, oid = meta.decode('ascii').split()
        result[path.decode('utf-8')] = {'mode': mode, 'type': kind, 'oid': oid}
    return result

def production(path):
    return path.startswith(PREFIXES) or path in FILES or (
        path.startswith('scripts/') and not path.startswith('scripts/validation/'))

def state():
    return {'head': text('rev-parse', 'HEAD').strip(),
            'tree': text('rev-parse', 'HEAD^{tree}').strip(),
            'status_porcelain_all': text('status', '--porcelain=v1', '--untracked-files=all'),
            'index_diff': text('diff', '--cached', '--name-status'),
            'worktree_diff': text('diff', '--name-status'),
            'gitdir': text('rev-parse', '--absolute-git-dir').strip()}

start = state()
assert start['head'] == FINAL and start['tree'] == TREE
assert not any(start[k] for k in ('status_porcelain_all', 'index_diff', 'worktree_diff'))
published = json.loads((OUT / 'published-commit.json').read_text())
assert published['sha'] == REMOTE and published['tree']['sha'] == TREE
assert text('rev-parse', REMOTE + '^{tree}').strip() == TREE
remote_diff = git('diff', '--binary', FINAL, REMOTE)
(OUT / 'local-vs-published.diff').write_bytes(remote_diff)
assert not remote_diff
trees = {ref: tree(ref) for ref in (FINAL, TESTED, BASE)}
paths = sorted({p for ref in (FINAL, TESTED) for p in trees[ref] if production(p)})
rows = []
cache = {}
for path in paths:
    a, b = trees[FINAL].get(path), trees[TESTED].get(path)
    assert a == b, ('production_tree_mismatch', path, a, b)
    row = {'path': path, 'final': a, 'tested': b}
    if a['type'] == 'blob':
        if a['oid'] not in cache:
            cache[a['oid']] = hashlib.sha256(git('cat-file', 'blob', a['oid'])).hexdigest()
        row['sha256'] = cache[a['oid']]
        fp = REPO / path
        if a['mode'] == '120000':
            actual = str(fp.readlink()).encode('utf-8')
        else:
            actual = fp.read_bytes()
        row['working_file_sha256'] = hashlib.sha256(actual).hexdigest()
        row['bytes'] = len(actual)
        assert row['sha256'] == row['working_file_sha256'], ('working_file_mismatch', path)
    else:
        row['disk_note'] = 'Gitlink commit equality checked; not claiming submodule checkout availability.'
    rows.append(row)
write('production-manifest.json', {'scope': {'prefixes': PREFIXES, 'files': FILES,
      'additional': 'scripts/** excluding scripts/validation/**'},
      'count': len(rows), 'paths': rows})
(OUT / 'production-vs-tested.diff').write_bytes(git('diff', '--binary', TESTED, FINAL, '--', *paths))
assert not (OUT / 'production-vs-tested.diff').read_bytes()
measure = []
for path in MEASUREMENT:
    entries = {ref: trees[ref][path] for ref in (BASE, TESTED, FINAL)}
    assert len({json.dumps(e, sort_keys=True) for e in entries.values()}) == 1
    blob = git('cat-file', 'blob', entries[FINAL]['oid'])
    actual = (REPO / path).read_bytes()
    assert blob == actual
    measure.append({'path': path, 'entries': entries, 'bytes': len(blob),
                    'sha256': hashlib.sha256(blob).hexdigest(),
                    'working_file_sha256': hashlib.sha256(actual).hexdigest()})
write('frozen-measurement-manifest.json', measure)
(OUT / 'measurement-vs-d66.diff').write_bytes(git('diff', '--binary', BASE, FINAL, '--', *MEASUREMENT))
assert not (OUT / 'measurement-vs-d66.diff').read_bytes()
all_diff = text('diff', '--name-status', TESTED, FINAL)
(OUT / 'all-changes-vs-tested.txt').write_text(all_diff)
changed = [line.split('\t')[-1] for line in all_diff.splitlines()]
changed_code = [p for p in changed if p.endswith('.py') and not p.startswith('evidence/')]
end = state()
assert start == end
report = {'status': 'PASS', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'repo': str(REPO), 'published_commit': REMOTE, 'local_commit': FINAL,
          'published_and_local_tree': TREE, 'tested_commit': TESTED, 'measurement_reference': BASE,
          'production_files': len(rows), 'astrolabe_files': sum(p.startswith('astrolabe/') for p in paths),
          'gitlinks': sum(r['final']['type'] != 'blob' for r in rows),
          'production_exact_blob_and_working_file_match': True,
          'four_measurement_files_exact_d66': True,
          'published_object_verified_via': published['url'],
          'source_tree_change_outside_production_scope': changed_code,
          'scope_limit': 'Whole repository differs from f9 because validation, launcher, tests, documents and evidence were added; production execution source under the recorded scope is byte-identical. No test, scientific workload, import profile or GPU process was executed by this audit.',
          'state_before': start, 'state_after': end}
write('source-audit.json', report)
print(json.dumps({k:report[k] for k in ('status','published_commit','published_and_local_tree','production_files','astrolabe_files','gitlinks','source_tree_change_outside_production_scope')}, indent=2))
