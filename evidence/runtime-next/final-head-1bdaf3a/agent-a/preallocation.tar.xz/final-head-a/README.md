# Agent A: final source and pre-allocation audit

## Result

**PASS — read-only exact-source audit.** GitHub's commit API independently returned published commit `1bdaf3a53227c9197b930dc00a01b752acd90067` with tree `6f763bfb04778ef4f32386ddb8aeb38ce4240bf1`. Local `integration-f102` commit `5db26b44cdf2d229ca35558f611b8b645ead881b` has that same tree; their complete tree diff is empty. Both pre- and post-audit working-tree/index status are empty.

Against the actually tested `f9ce87b9f5cf37710f0a52ebe503595e5d7fdd7f`, the 948 recorded production paths are identical in Git object/mode, including all 275 `astrolabe/**` paths. The manifest covers execution code, configuration, packaging, container definitions, resources, data, examples and non-validation scripts. For all 917 ordinary blobs, the current filesystem SHA256 also equals the Git blob SHA256. The remaining 31 entries are identical Gitlink commit references; this audit does not claim their submodules are materialized locally. `production-vs-tested.diff` is empty.

All four frozen measurement modules are byte-identical to `d66ee714f2e755948534f95d9d125287ce8dbd91` and to tested f9. Their exact paths and SHA256 are in `frozen-measurement-manifest.json`; `measurement-vs-d66.diff` is empty.

The entire repository is not claimed identical to f9: launcher, validation entry/certification, tests, documents and evidence were subsequently added or updated. `all-changes-vs-tested.txt` records the complete difference; `source-audit.json` lists the five changed non-evidence Python paths outside the production scope.

## Scheduler snapshot: 2026-11-04 05:46:46–47 UTC

Both independent native read-only requests exited 0 without output truncation. No remote files were written, GPU hardware queried, jobs submitted, scientific evaluations executed or profiles run.

| Field | Observed value |
|---|---|
| User / UID | zpzeng / 7054 |
| Login host | f102.hn.org |
| Inherited allocation | No job ID, job GPUs, step GPUs or CUDA visibility |
| Partition / node | boron UP / f146 MIXED |
| GPU scheduler count | 6 configured, 5 allocated; 1 arithmetically unallocated |
| CPU scheduler count | 56 configured, 40 allocated; 16 unallocated |
| Memory scheduler count | 240000 MiB configured, 202880 MiB allocated; 37120 MiB unallocated |
| Requested fixed budget | A new independent 1 × g4090, 4 CPU, 32768 MiB, 900 s allocation |
| Maximum requested GPU cost | 0.25 GPU-hours, including setup, failed work and teardown inside the allocation |

The reported headroom fits that explicit request arithmetically; it is not a reservation or allocation proof. The new job must pass the existing launcher's exact resource and ownership gates. Partition defaults (8 CPU / 40000 MiB per GPU) do not replace the explicitly frozen 4 CPU / 32 GiB request.

The own-user queue snapshot records 13 running tasks from existing GPU array `31793` on carbon/iron/nitrogen and a held pending CPU array `22410` on helium. They were read only, are unrelated to this experiment, and must not be attached to, altered or reused. No new Astrolabe job exists in this snapshot.

## Pending actual job audit

**PENDING — no new job ID has been supplied.** After root's single authorized submission, only that exact job's metadata and resulting artifacts may be read. The independent audit will verify UID, name, partition/account/QOS, one typed g4090, 4 CPU, 32 GiB, actual allocation/terminal state, and both `ElapsedRaw / 3600` and `(End − Start) / 3600` GPU-hours. No successful resource-release or GPU validation claim is made here before that evidence exists. Delayed or inconsistent accounting remains PARTIAL.

## Evidence / reproduction

Run `python control/final-head-a/audit_final_source.py` from the local `cloud-20261104` directory; the script is read only with respect to all source trees and writes only this evidence directory. It does not import Astrolabe or execute tests.

`published-commit.json` contains the independent GitHub API response. `source-audit.json`, both source manifests and the three empty diff files establish the exact source boundaries. `scheduler-boron.json` and `scheduler-own_jobs.json` retain the complete native request argv, UTC and raw outputs. All files are inventoried by the pre-allocation archive manifest.
