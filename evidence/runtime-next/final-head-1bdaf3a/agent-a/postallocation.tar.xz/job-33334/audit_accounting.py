"""Independent offline audit of captured, read-only own-job 33334 metadata."""
import datetime
import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent
JOB = '33334'
NAME = 'astrolabe-gpu-20261104-10cf2b34c104'
FIELDS = ['JobIDRaw', 'JobName', 'User', 'UID', 'Account', 'Partition', 'QOS',
          'State', 'ExitCode', 'Submit', 'Eligible', 'Start', 'End', 'ElapsedRaw',
          'AllocCPUS', 'NNodes', 'ReqTRES', 'AllocTRES', 'NodeList']

def raw(name):
    r = json.loads((ROOT / (name + '.json')).read_text())
    result = r['response']['result']
    assert r['response']['execution'] == 'accepted'
    assert result['status'] == 'exited' and result['exitCode'] == 0
    assert result['outputTruncated'] is False and not result['stderr']
    return r, result['stdout']

sacct_record, sacct = raw('sacct')
rows = [dict(zip(FIELDS, row.split('|'))) for row in sacct.splitlines()]
assert len(rows) == 1 and len(sacct.strip().split('|')) == len(FIELDS)
job = rows[0]
assert (job['JobIDRaw'], job['JobName'], job['User'], job['UID']) == (JOB, NAME, 'zpzeng', '7054')
assert (job['Account'], job['Partition'], job['QOS']) == ('xulab', 'boron', 'normal')
assert job['State'] == 'CANCELLED by 7054'
assert job['Start'] == 'None' and job['End'] == '2026-11-04T05:52:06'
assert job['ElapsedRaw'] == '0' and job['AllocCPUS'] == '0'
assert job['AllocTRES'] == '' and job['NodeList'] == 'None assigned'
fmt = '%Y-%m-%dT%H:%M:%S'
queue_seconds = (datetime.datetime.strptime(job['End'], fmt) - datetime.datetime.strptime(job['Submit'], fmt)).total_seconds()
assert queue_seconds == 60

control_record, control = raw('scontrol')
fields = dict(re.findall(r'(?:^| )([A-Za-z][A-Za-z0-9_:/]*)=(.*?)(?= [A-Za-z][A-Za-z0-9_:/]*=|$)', control.strip()))
assert fields['JobId'] == JOB and fields['JobName'] == NAME
assert fields['UserId'] == 'zpzeng(7054)' and fields['JobState'] == 'CANCELLED'
assert fields['AllocTRES'] == '(null)' and fields['NodeList'] == ''
assert (fields['Account'], fields['Partition'], fields['QOS']) == ('xulab', 'boron', 'normal')
queue_record, queue = raw('squeue')
assert not queue.strip(), 'Own job remains in the active queue'

launcher_record, launcher = raw('launcher-raw')
payload = json.loads(launcher)
assert payload['allocation_json_exists'] is False
assert payload['inside_error_json_exists'] is False
for row in payload['files']:
    content = row['text'].encode('utf-8')
    assert len(content) == row['bytes'] and hashlib.sha256(content).hexdigest() == row['sha256']
    (ROOT / row['path']).write_bytes(content)
submission = json.loads((ROOT / 'submission.json').read_text())
assert submission['srun_exit_code'] == 1 and submission['existing_job_reuse'] is False
assert submission['status'] == 'PARTIAL_ACCOUNTING_OR_BUDGET'
stderr = (ROOT / 'srun.stderr.txt').read_text()
assert 'srun: job 33334 queued and waiting for resources' in stderr
assert 'Unable to allocate resources: Requested nodes are busy' in stderr
assert not (ROOT / 'srun.stdout.txt').read_bytes()
argv = submission['srun_argv']
required = ('--account=xulab', '--partition=boron', '--qos=normal', '--nodes=1',
            '--ntasks=1', '--gres=gpu:g4090:1', '--cpus-per-task=4', '--mem=32G',
            '--time=00:15:00', '--immediate=60', '--job-name=' + NAME)
assert all(arg in argv for arg in required)
_, context = raw('post-busy-boron')
context = json.loads(context)
summary = {
    'status': 'DONE_ACCOUNTING_NO_ALLOCATION',
    'gpu_validation_status': 'BLOCKED_SCHEDULER_ALLOCATION',
    'job_id': JOB, 'job_name': NAME, 'user': 'zpzeng', 'uid': 7054,
    'account': 'xulab', 'partition': 'boron', 'qos': 'normal',
    'terminal_state': job['State'], 'srun_exit_code': 1,
    'accounting_exit_code': job['ExitCode'],
    'actual_start': None, 'actual_end_utc': job['End'] + 'Z',
    'elapsed_raw_seconds': 0, 'actual_allocated_gpu_count': 0,
    'actual_allocation_gpu_hours': 0.0,
    'allocation_end_minus_start_seconds': None,
    'end_minus_start_note': 'No actual allocation start exists. Do not subtract the future scontrol timestamp from End.',
    'allocation_evidence': ['sacct Start=None / ElapsedRaw=0 / AllocCPUS=0 / AllocTRES empty / NodeList=None assigned',
                            'scontrol CANCELLED / AllocTRES=(null) / NodeList empty',
                            'Own-job squeue empty', 'allocation.json absent and srun reports failed resource allocation'],
    'submit_to_terminal_seconds': queue_seconds,
    'client_wall_seconds': submission['client_wall_seconds'],
    'requested_gpu_limit': 1, 'requested_allocation_limit_seconds': 900,
    'requested_gpu_hours_ceiling': 0.25,
    'requested_limit_is_not_usage': True,
    'gpu_inference_trials_in_this_job': 0,
    'scontrol_nonexecution_start_timestamp': fields['StartTime'],
    'scontrol_runtime': fields['RunTime'], 'scontrol_reason': fields['Reason'],
    'scontrol_req_tres': fields['ReqTRES'], 'scontrol_mem_per_tres': fields['MemPerTres'],
    'scontrol_min_memory_tres': fields['MinMemoryTRES'],
    'scheduler_snapshot_utc': context['utc'],
    'scheduler_arithmetic_only': context['nodes'][0],
    'causal_scope': 'Busy is the actual admission result; Reason=Priority and retained per-GPU memory fields are recorded. Arithmetic node headroom did not establish schedulability. No unique scheduler root cause or memory-override guarantee is inferred.',
    'read_only_review_scope': 'Only exact own job 33334, boron scheduler metadata and own launcher log files were read. No GPU query, cancellation, retry, allocation or scientific execution was issued by this audit.',
    'primary_field_semantics': {
        'AllocTRES': 'https://slurm.schedmd.com/sacct.html#OPT_AllocTres',
        'ElapsedRaw': 'https://slurm.schedmd.com/sacct.html#OPT_ElapsedRaw'},
    'query_utc': {'sacct': sacct_record['queried_at'], 'scontrol': control_record['queried_at'], 'squeue': queue_record['queried_at']},
}
(ROOT / 'accounting-proof.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: summary[k] for k in ('status', 'gpu_validation_status', 'job_id', 'terminal_state', 'actual_allocated_gpu_count', 'actual_allocation_gpu_hours', 'submit_to_terminal_seconds', 'client_wall_seconds')}, indent=2))
