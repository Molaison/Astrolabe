"""Python 3.6-compatible, read-only, explicitly scoped worktree snapshot."""
import base64
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import zlib

spec = json.loads(sys.argv[1])
root = pathlib.Path(spec['worktree'])
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
calls = []

def git(args, compact=False):
    p = subprocess.run(['git'] + args, cwd=str(root), env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=6)
    row = {'argv': ['git'] + args, 'exit': p.returncode,
           'stderr': p.stderr.decode('utf-8', 'replace')}
    if compact:
        row.update(bytes=len(p.stdout), sha256=hashlib.sha256(p.stdout).hexdigest())
    else:
        row['stdout'] = p.stdout.decode('utf-8', 'replace')
    calls.append(row)
    if p.returncode:
        raise RuntimeError(row)
    return p.stdout

head = git(['rev-parse', 'HEAD']).decode().strip()
branch = git(['rev-parse', '--abbrev-ref', 'HEAD']).decode().strip()
status = git(['status', '--porcelain=v1', '--untracked-files=normal', '--ignore-submodules']).decode()
gd = git(['rev-parse', '--git-dir']).decode().strip()
cd = git(['rev-parse', '--git-common-dir']).decode().strip()
paths = spec['tracked_paths']
# Limit diff content reads to the original modified files. Review has no diff.
diff = git(['diff', '--no-ext-diff', '--binary', 'HEAD', '--'] + paths, compact=True) if paths else b''
files = {}
for path in spec['files']:
    p = root / path
    if p.is_symlink():
        files[path] = {'symlink': os.readlink(str(p)), 'sha256': None}
    elif p.is_file():
        n = p.stat().st_size
        if n > 2000000:
            files[path] = {'bytes': n, 'error': 'bounded audit will not hash files above 2 MB'}
        else:
            b = p.read_bytes()
            files[path] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
    elif p.exists():
        files[path] = {'error': 'not a regular file'}
    else:
        files[path] = {'sha256': None, 'missing': True}
out = {'utc': datetime.datetime.utcnow().isoformat()+'Z', 'worktree': str(root),
       'realpath': str(root.resolve()), 'head': head, 'branch': branch, 'status': status,
       'git_dir': gd, 'common_dir': cd, 'git_pointer_is_file': (root/'.git').is_file(),
       'tracked_diff_bytes': len(diff), 'tracked_diff_sha256': hashlib.sha256(diff).hexdigest(),
       'files': files, 'git_calls': calls,
       'scope': 'Only original modified/untracked and previously hashed owner/report files; no resource/model scan; GIT_OPTIONAL_LOCKS=0; no writes'}
raw = json.dumps(out, sort_keys=True, separators=(',', ':')).encode('utf-8')
print(json.dumps({'encoding': 'base64+zlib', 'payload_bytes': len(raw),
                  'payload_sha256': hashlib.sha256(raw).hexdigest(),
                  'payload': base64.b64encode(zlib.compress(raw, 9)).decode('ascii')}))
