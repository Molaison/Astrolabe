import base64
import hashlib
import json
import pathlib
import zlib

ROOT = pathlib.Path(__file__).resolve().parent
expected = json.loads((ROOT / 'expected.json').read_text())
rows = {}
differences = []
for name in ('review', 'fix', 'opt'):
    record = json.loads((ROOT / (name + '-native.json')).read_text())
    response = record['response']
    result = response['result']
    assert response['execution'] == 'accepted' and result['status'] == 'exited'
    assert result['exitCode'] == 0 and not result['stderr'] and not result['outputTruncated']
    packed = json.loads(result['stdout'])
    data = zlib.decompress(base64.b64decode(packed['payload']))
    assert len(data) == packed['payload_bytes']
    assert hashlib.sha256(data).hexdigest() == packed['payload_sha256']
    current = json.loads(data)
    (ROOT / (name + '-current.json')).write_text(json.dumps(current, indent=2, sort_keys=True) + '\n')
    before = expected[name]
    checks = {}
    for key in ('worktree', 'head', 'branch', 'status', 'git_dir', 'common_dir',
                'tracked_diff_bytes', 'tracked_diff_sha256'):
        checks[key] = current[key] == before[key]
        if not checks[key]:
            differences.append({'worktree': name, 'field': key, 'before': before[key], 'current': current[key], 'owner': 'UNKNOWN'})
    files = []
    for path, old in before['files'].items():
        new = current['files'][path]
        ok = ('error' not in new and 'symlink' not in new and new.get('sha256') == old['sha256']
              and ('bytes' not in old or old['bytes'] == new.get('bytes')))
        files.append({'path': path, 'match': ok, 'before': old, 'current': new})
        if not ok:
            differences.append({'worktree': name, 'path': path, 'before': old, 'current': new, 'owner': 'UNKNOWN'})
    tracked_count = len(before['tracked_paths'])
    untracked_count = sum(line.startswith('?? ') for line in before['status'].splitlines())
    rows[name] = {'status': 'PASS' if all(checks.values()) and all(f['match'] for f in files) else 'DIFFERENCE_UNKNOWN_OWNER',
                  'utc': current['utc'], 'worktree': current['worktree'], 'head': current['head'],
                  'original_tracked_modifications': tracked_count, 'original_untracked_files': untracked_count,
                  'metadata_checks': checks, 'original_modified_files_preserved': tracked_count + untracked_count,
                  'total_scoped_paths_checked': len(files),
                  'actual_regular_files_hashed': sum(v.get('sha256') is not None for v in current['files'].values()),
                  'actual_bytes_hashed': sum(v.get('bytes', 0) for v in current['files'].values()),
                  'files': files}
report = {'status': 'PASS_PRESERVED' if not differences else 'DIFFERENCES_UNKNOWN_OWNER',
          'worktrees': rows, 'differences': differences,
          'scope': 'Three original linked worktrees; full normal-mode status/HEAD/branch/topology, all original modified tracked/untracked source and test files, plus originally hashed owner/report files. No whole-resource or model scan. No write, checkout, restoration or scientific execution.',
          'limit': 'A before/after content and state comparison. Unlisted ignored artifacts and transient changes between observations are outside its scope.',
          'initial_evidence_root': 'control/f102-source-preflight',
          'tracked_hash_derivation': 'Each original tracked postimage reconstructed in memory from exact d66 blob plus preserved original patch; every context and hunk count, old/new Git blob prefix, full patch SHA and overlapping initial direct SHA checked.',
          'remote_mutations': 0, 'scientific_evaluations': 0, 'gpu_queries': 0}
(ROOT / 'preservation-proof.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': report['status'], 'differences': differences,
                  'worktrees': {name: {k: r[k] for k in ('status','utc','head','original_tracked_modifications','original_untracked_files','total_scoped_paths_checked','actual_regular_files_hashed','actual_bytes_hashed')} for name,r in rows.items()}}, indent=2))
