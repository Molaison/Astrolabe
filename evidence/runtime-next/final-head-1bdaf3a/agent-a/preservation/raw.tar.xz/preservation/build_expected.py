"""Recover exact original tracked postimages from the preserved patch in memory."""
import hashlib
import json
import pathlib
import re
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
BASE = HERE.parents[2]
OLD = BASE / 'control/f102-source-preflight'
REPO = BASE / 'integration-f102'
HEAD = 'd66ee714f2e755948534f95d9d125287ce8dbd91'
initial = json.loads((OLD / 'source-preflight.json').read_text())
native = json.loads((OLD / 'native-read-observations-final.json').read_text())
# The original bounded response's later, unrelated old-test row was truncated.
# Its first review object is complete and can be decoded without that tail.
review, _ = json.JSONDecoder().raw_decode(native['10'][0]['result']['stdout'].lstrip()[1:])
assert review['path'] == 'cloud-20261103-review'
topology = {pathlib.Path(x['path']).name: x for x in initial['remote_topology']['checkouts']}
out = {}

def recover(patch):
    assert b'\\ No newline at end of file' not in patch and b'GIT binary patch' not in patch
    result = {}
    for block in re.split(br'(?m)^diff --git ', patch)[1:]:
        lines = block.splitlines(keepends=True)
        a, b = lines[0].strip().split(b' ')
        assert a.startswith(b'a/') and b.startswith(b'b/') and a[2:] == b[2:]
        path = a[2:].decode()
        base = subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=str(REPO))
        original = base.splitlines(keepends=True)
        content = []
        cursor = 0
        i = 1
        while i < len(lines):
            if not lines[i].startswith(b'@@ '):
                i += 1
                continue
            h = re.match(br'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i])
            assert h
            old_start = int(h.group(1)) - 1
            old_count = int(h.group(2) or b'1')
            new_count = int(h.group(4) or b'1')
            assert old_start >= cursor
            content.extend(original[cursor:old_start])
            cursor = old_start
            used_old = used_new = 0
            i += 1
            while i < len(lines) and not lines[i].startswith(b'@@ '):
                line = lines[i]
                assert line[:1] in (b' ', b'+', b'-'), (path, line)
                if line[:1] in (b' ', b'-'):
                    assert original[cursor] == line[1:], (path, cursor)
                    cursor += 1
                    used_old += 1
                if line[:1] in (b' ', b'+'):
                    content.append(line[1:])
                    used_new += 1
                i += 1
            assert (used_old, used_new) == (old_count, new_count)
        content.extend(original[cursor:])
        data = b''.join(content)
        index = re.search(br'(?m)^index ([a-f0-9]+)\.\.([a-f0-9]+)', block)
        for blob, prefix in ((base, index.group(1)), (data, index.group(2))):
            oid = hashlib.sha1(b'blob ' + str(len(blob)).encode() + b'\0' + blob).hexdigest()
            assert oid.startswith(prefix.decode())
        result[path] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'basis': 'original preserved patch + exact d66 blob'}
    return result

for name in ('review', 'fix', 'opt'):
    long_name = 'cloud-20261103-' + name
    topo = topology[long_name]
    if name == 'review':
        row = {'worktree': topo['path'], 'head': review['head']['lines'][0],
               'branch': review['branch']['lines'][0], 'status': '',
               'tracked_paths': [], 'tracked_diff_sha256': hashlib.sha256(b'').hexdigest(),
               'tracked_diff_bytes': 0}
        assert review['status']['lines'] == []
        files = {}
    else:
        m = json.loads((OLD / name / 'snapshot-manifest.json').read_text())
        patch = (OLD / name / 'tracked.patch').read_bytes()
        assert hashlib.sha256(patch).hexdigest() == m['tracked_diff_sha256']
        files = recover(patch)
        row = {k: m[k] for k in ('worktree', 'head', 'branch', 'status', 'tracked_diff_sha256', 'tracked_diff_bytes')}
        row['tracked_paths'] = sorted(files)
        for f in m['untracked']:
            data = (OLD / name / 'untracked' / f['path']).read_bytes()
            assert hashlib.sha256(data).hexdigest() == f['sha256'] and len(data) == f['bytes']
            files[f['path']] = {'sha256': f['sha256'], 'bytes': f['bytes'], 'basis': 'original untracked snapshot'}
    index = initial['eight_production_file_overlap']['trees'].index(long_name)
    for path, hashes in initial['eight_production_file_overlap']['file_sha256'].items():
        if path in files:
            assert files[path]['sha256'] == hashes[index]
        else:
            files[path] = {'sha256': hashes[index], 'basis': 'original relevant-owner hash snapshot'}
    for basename, digest in initial['existing_report_hashes'][long_name].items():
        path = 'docs/' + basename
        if path in files:
            assert files[path]['sha256'] == digest
        else:
            files[path] = {'sha256': digest, 'basis': 'original report hash snapshot'}
    row['git_dir'] = topo['git_dir']['stdout'].strip()
    row['common_dir'] = topo['common_dir']['stdout'].strip()
    row['files'] = dict(sorted(files.items()))
    out[name] = row
(HERE / 'expected.json').write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: {'paths': len(v['files']), 'tracked_original_changes': len(v['tracked_paths'])} for k, v in out.items()}))
