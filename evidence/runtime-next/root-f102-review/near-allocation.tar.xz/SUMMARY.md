# Scheduler headroom immediately before root's allocation decision

Observed at **2026-11-04 05:15:31–33 UTC**, through read-only native argv on f102.
No GPU hardware query, model import, container, Slurm submission, cancellation,
attachment, or remote filesystem write was performed by these queries.

The shell is user `zpzeng`, UID 7054, without inherited job/GPU/CUDA allocation
variables. Its visible existing queue still contains the unrelated 13 running GPU
array tasks and the held CPU array recorded by the earlier preflight; none was
modified or reused. The complete own-job output is preserved in `own_jobs.json`.

| Scheduler fact | Value |
|---|---|
| Partition | boron, UP, normal QOS, OverSubscribe=NO |
| Reported node | f146, MIXED |
| GPU configuration / allocated | 6 / 5, type g4090 |
| Reported unallocated CPUs | 16 |
| Reported unallocated RAM | 37,120 MiB |
| Fixed requested fit | 1 GPU, 4 CPUs, 32 GiB passes arithmetic headroom filter |

This is a staleable scheduler snapshot, not an allocation or a guarantee that the
request will be admitted. Root should retain the reviewed one-shot srun request,
its 60 s admission bound, and the inside verification of actual assigned resources.
It should not pin the observed node or a physical GPU based on this inventory.

The partition reports default `DefCpuPerGPU=8` and `DefMemPerGPU=40000`. Official
[slurm.conf documentation](https://slurm.schedmd.com/slurm.conf.html) specifies that
the CPU default applies when neither explicit per-task nor per-GPU CPU allocation
is supplied. The official [srun documentation](https://slurm.schedmd.com/srun.html)
and [consumable resource guide](https://slurm.schedmd.com/cons_tres_share.html)
describe explicit memory options overriding default requests. The frozen
`--cpus-per-task=4 --mem=32G` therefore remains appropriate; the launcher still
checks actual NumCPUs and memory before model execution. No request was changed.

`boron.json` contains complete untruncated native responses for the partition,
node listing, and node record. `commands.json` preserves both exact host Python
query programs. Every command completed with exit zero. The query programs use
Python 3.6-compatible subprocess APIs and write nothing remotely.
