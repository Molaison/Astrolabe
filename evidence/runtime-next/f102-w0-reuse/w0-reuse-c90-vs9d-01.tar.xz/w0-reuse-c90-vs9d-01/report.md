# Runtime CPU W0 comparison

Status: **DONE**. Completed trial contract: **True**.
Baseline: `9d62b3eb86cb75a2266af49dc48cb851e69e0341`. Candidate: `c90fadfdb82e2ba81b596b8d1cc93c4a25e783c4`.
Protocol: `f2636de19cdb90c2707a24969da016c398ba13b71c70fc4cde7e2fa00e7855e5`. 30 / 30 trials attempted.

| Revision / mode | Valid / attempted | Evaluations | Median seconds | Range seconds | Effective trajectories/s |
| --- | ---: | ---: | ---: | --- | ---: |
| baseline/direct | 5 / 5 | 45 | 10.7273 | 9.8941 – 15.7950 | 0.2482 |
| baseline/resident_serial | 5 / 5 | 45 | 33.2943 | 30.5781 – 41.3694 | 0.0846 |
| baseline/resident_adaptive | 5 / 5 | 45 | 33.2322 | 30.2160 – 37.8789 | 0.0898 |
| candidate/direct | 5 / 5 | 45 | 9.6860 | 9.3388 – 17.3680 | 0.2589 |
| candidate/resident_serial | 5 / 5 | 45 | 33.7630 | 31.2284 – 41.3118 | 0.0845 |
| candidate/resident_adaptive | 5 / 5 | 45 | 32.7041 | 32.2641 – 35.0838 | 0.0906 |

Scientific gate across both revisions and every mode: **True**.
Baseline direct repeats alone define numerical tolerance. Candidate direct cannot widen it.

| Same mode | Median baseline / candidate seconds | Faster pairs / 5 | All five improved | Nonoverlapping time ranges |
| --- | ---: | ---: | --- | --- |
| direct | 1.0744 | 4 | False | False |
| resident_serial | 1.0014 | 3 | False | False |
| resident_adaptive | 1.0092 | 3 | False | False |

Ratios above one favor the candidate. Incomplete work or failed scientific/release checks suppress every speed ratio and effective-throughput number.

| Candidate mode | Best direct revision | Median direct / candidate seconds |
| --- | --- | ---: |
| direct | candidate | 1.0000 |
| resident_serial | candidate | 0.2990 |
| resident_adaptive | candidate | 0.2941 |

CPU W0 timings only; inspect paired variation

BLOCKED: CPU Dummy workload, no model weights or GPU execution

All trials start fresh; no warmup, extra trajectories or profiler is added. The existing 30 ms observer times process-tree completion and verifies release. Raw stdout/stderr, configs, traces, telemetry, source manifests, scientific rows and failed trials are retained.
